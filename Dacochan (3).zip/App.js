import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import { AppLoading } from "expo";
import * as Font from "expo-font";
import Dashboard from "./src/screens/Dashboard";
import Feedback from "./src/screens/Feedback";
import History from "./src/screens/History";
import Liquidate from "./src/screens/Liquidate";
import Login from "./src/screens/Login";
import PreProcessLiquidate from "./src/screens/PreProcessLiquidate";
import PreProcessTopup from "./src/screens/PreProcessTopup";
import Settings from "./src/screens/Settings";
import SignUp from "./src/screens/SignUp";
import Topup from "./src/screens/Topup";
import Transaction from "./src/screens/Transaction";
import QrCode from "./src/screens/QrCode";

const DrawerNavigation = createDrawerNavigator({
  Dashboard: Dashboard,
  Feedback: Feedback,
  History: History,
  Liquidate: Liquidate,
  Login: Login,
  PreProcessLiquidate: PreProcessLiquidate,
  PreProcessTopup: PreProcessTopup,
  Settings: Settings,
  SignUp: SignUp,
  Topup: Topup,
  Transaction: Transaction,
  QrCode: QrCode
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    Dashboard: Dashboard,
    Feedback: Feedback,
    History: History,
    Liquidate: Liquidate,
    Login: Login,
    PreProcessLiquidate: PreProcessLiquidate,
    PreProcessTopup: PreProcessTopup,
    Settings: Settings,
    SignUp: SignUp,
    Topup: Topup,
    Transaction: Transaction,
    QrCode: QrCode
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "alegreya-sans-sc-700": require("./src/assets/fonts/alegreya-sans-sc-700.ttf"),
      "baumans-regular": require("./src/assets/fonts/baumans-regular.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
